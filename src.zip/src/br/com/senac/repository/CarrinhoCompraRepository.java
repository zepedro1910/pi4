package br.com.senac.repository;

import br.com.senac.domain.CarrinhoDeCompra;

public interface CarrinhoCompraRepository {

      public Long salvarCarrinho(CarrinhoDeCompra carrinho);

}
