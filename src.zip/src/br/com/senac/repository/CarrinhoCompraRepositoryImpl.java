package br.com.senac.repository;

import javax.inject.Inject;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import br.com.senac.domain.CarrinhoDeCompra;

@Repository
public class CarrinhoCompraRepositoryImpl implements CarrinhoCompraRepository {

      private final HibernateTemplate hibernateTemplate;

      @Inject
      public CarrinhoCompraRepositoryImpl(final HibernateTemplate hibernateTemplate) {
            super();
            this.hibernateTemplate = hibernateTemplate;
      }

      @Override
      public Long salvarCarrinho(final CarrinhoDeCompra carrinho) {
            hibernateTemplate.merge(carrinho);
            return carrinho.getId();
      }

}
