package br.com.senac.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.senac.domain.CarrinhoDeCompra;
import br.com.senac.repository.CarrinhoCompraRepository;

@Service
public class CarrinhoCompraServiceImpl implements CarrinhoCompraService {

      private final CarrinhoCompraRepository carrinhoRepository;

      @Inject
      public CarrinhoCompraServiceImpl(final CarrinhoCompraRepository carrinhoRepository) {
            super();
            this.carrinhoRepository = carrinhoRepository;
      }

      @Override
      public Long validarCarrinho(final CarrinhoDeCompra carrinho) {
            return carrinhoRepository.salvarCarrinho(carrinho);
      }

}
