package br.com.senac.service;

import br.com.senac.domain.CarrinhoDeCompra;

public interface CarrinhoCompraService {

      Long validarCarrinho(CarrinhoDeCompra carrinho);

}
