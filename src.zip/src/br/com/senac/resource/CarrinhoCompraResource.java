package br.com.senac.resource;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.senac.domain.CarrinhoDeCompra;
import br.com.senac.service.CarrinhoCompraService;

@RestController
@RequestMapping(value = "/carrinho")
public class CarrinhoCompraResource {

      private final CarrinhoCompraService carrinhoService;

      @Inject
      public CarrinhoCompraResource(final CarrinhoCompraService carrinhoService) {
            super();
            this.carrinhoService = carrinhoService;
      }

      @RequestMapping(value = "/salvar")
      public Long salvarCarrinho(@RequestBody final CarrinhoDeCompra carrinho) {
            return carrinhoService.validarCarrinho(carrinho);
      }

}
