package br.com.senac.domain;

public enum Cargo {

      OPERACIONAL, //
      GERENCIA;
}
