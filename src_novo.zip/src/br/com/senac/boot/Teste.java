package br.com.senac.boot;

import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Teste {

      @Test
      public void gerarJson() {

            final ObjectMapper mapper = new ObjectMapper();

      }
}
