
package br.com.senac.domain;

import java.io.Serializable;
import java.util.ArrayList;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "TB_CARRINHO_COMPRA")
public class CarrinhoDeCompra implements Serializable{
	private static final long serialVersionUID = -7016269234259164121L;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private Long id;
	
	@Column(name = "PRODUTOS",length = 1000000)
	@CollectionTable(name = "lista_produtos")
	private ArrayList<VinilVO> produtos;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ArrayList<VinilVO> getProdutos() {
		return produtos;
	}

	public void setProdutos(ArrayList<VinilVO> produtos) {
		this.produtos = produtos;
	}
	
	
	
}
