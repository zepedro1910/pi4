package br.com.senac.service;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.inject.Inject;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sun.org.apache.regexp.internal.recompile;

import br.com.senac.domain.CarrinhoDeCompra;
import br.com.senac.domain.Usuario;
import br.com.senac.domain.Vinil;
import br.com.senac.domain.VinilVO;
import br.com.senac.repository.UsuarioRepository;

@Service
public class UsuarioServiceImpl implements UsuarioService {

	private final UsuarioRepository userRepository;
	private final HibernateTemplate hibernateTemplate;

	@Inject
	public UsuarioServiceImpl(final UsuarioRepository pessoaRepository, HibernateTemplate hibernateTemplate) {
		super();
		userRepository = pessoaRepository;
		this.hibernateTemplate = hibernateTemplate;
	}

	@Override
	public void save(final Usuario usuario) {
		// TODO

		userRepository.saveUsuario(usuario);
	}

	@Override
	public Integer countUser(final Map<String, Object> map) {
		final String nome = getNameKey(map);
		final String cpf = getCpfKey(map);
		return userRepository.countUser(nome, cpf);
	}

	@Override
	public List<Usuario> findUser(final Map<String, Object> map) {
		final int fistItem = (int) map.get("fistItem");
		final int lastItem = (int) map.get("maxResult");
		final String nome = getNameKey(map);
		final String cpf = getCpfKey(map);
		return userRepository.findUser(fistItem, lastItem, nome, cpf);
	}

	private String getNameKey(final Map<String, Object> map) {
		String nome = null;
		if (map.containsKey("nome")) {
			nome = (String) map.get("nome");
		}
		return nome;
	}

	private String getCpfKey(final Map<String, Object> map) {
		String cpf = null;
		if (map.containsKey("cpf")) {
			cpf = (String) map.get("cpf");
		}
		return cpf;
	}

	@Override
	public List<Usuario> checkLoginData(String email, String senha) {
		if (email != "" && senha != "") {
			userRepository.checkLoginDataUser(email, senha);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public Long addProduto(Map<String, Object> map) {

		Integer idCliente = null;
		Integer idProduto = null;
		Integer qtd = null;
		if (map.containsKey("idCliente")) {
			idCliente = (Integer) map.get("idCliente");
		}

		if (map.containsKey("idProduto")) {
			idProduto = (Integer) map.get("idProduto");
		}

		if (map.containsKey("qtd")) {
			qtd = (Integer) map.get("qtd");
		}

		DetachedCriteria criteria = DetachedCriteria.forClass(Usuario.class);
		criteria.add(Restrictions.eq("id", idCliente.longValue()));
		List<Usuario> userList = (List<Usuario>) hibernateTemplate.findByCriteria(criteria);

		DetachedCriteria produtoCriteria = DetachedCriteria.forClass(Vinil.class);
		produtoCriteria.add(Restrictions.eq("id", idProduto.longValue()));
		List<Vinil> vinilList = (List<Vinil>) hibernateTemplate.findByCriteria(produtoCriteria);

		if (!userList.isEmpty() && !vinilList.isEmpty()) {
			Usuario usuario = userList.get(0);
			Vinil vinil = vinilList.get(0);

			if (usuario.getCarrinho() == null) {
				usuario.setCarrinho(new CarrinhoDeCompra());
			}
			if (usuario.getCarrinho().getProdutos() == null) {
				usuario.getCarrinho().setProdutos(new ArrayList<VinilVO>());
			}
			if (vinil.getQuantidade() >= qtd) {
				vinil.setQuantidade(vinil.getQuantidade() - qtd);

				VinilVO vinilVO = new VinilVO();
				vinilVO.setId(vinil.getId());
				vinilVO.setNome(vinil.getNome());
				vinilVO.setCategoria(vinil.getCategoria());
				vinilVO.setDescricao(vinil.getDescricao());
				vinilVO.setImagem(vinil.getImagem());
				vinilVO.setInactive(vinil.isInactive());
				vinilVO.setPreco(vinil.getPreco());
				vinilVO.setQuantidade(qtd);
				usuario.getCarrinho().getProdutos().add(vinilVO);
			}
			hibernateTemplate.merge(vinil);
			hibernateTemplate.merge(usuario);
			return usuario.getId();
		}

		return 0L;

	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Usuario> allUsers() {
		return (List<Usuario>) hibernateTemplate.findByCriteria(DetachedCriteria.forClass(Usuario.class));
	}

	@Override
	@SuppressWarnings("unchecked")
	@Transactional(propagation = Propagation.REQUIRED)
	public Long concluirCompra(Map<String, Object> map) {
		Integer idCliente = null;
		if (map.containsKey("idCliente")) {
			idCliente = (Integer) map.get("idCliente");
		}

		DetachedCriteria criteria = DetachedCriteria.forClass(Usuario.class);
		criteria.add(Restrictions.eq("id", idCliente.longValue()));
		List<Usuario> userList = (List<Usuario>) hibernateTemplate.findByCriteria(criteria);

		if (!userList.isEmpty()) {
			Usuario usuario = userList.get(0);
			usuario.getCarrinho().getProdutos().clear();
			hibernateTemplate.merge(usuario);
			return usuario.getId();
		}
		return 0L;
	}

	@Override
	@SuppressWarnings("unchecked")
	@Transactional(propagation = Propagation.REQUIRED)
	public Long removerProduto(Map<String, Object> map) {
		Integer idCliente = null;
		Integer idProduto = null;
		Integer qtd = null;

		if (map.containsKey("qtd")) {
			qtd = (Integer) map.get("qtd");
		}

		if (map.containsKey("idCliente")) {
			idCliente = (Integer) map.get("idCliente");
		}

		if (map.containsKey("idProduto")) {
			idProduto = (Integer) map.get("idProduto");
		}

		DetachedCriteria criteria = DetachedCriteria.forClass(Usuario.class);
		criteria.add(Restrictions.eq("id", idCliente.longValue()));
		List<Usuario> userList = (List<Usuario>) hibernateTemplate.findByCriteria(criteria);

		DetachedCriteria produtoCriteria = DetachedCriteria.forClass(Vinil.class);
		produtoCriteria.add(Restrictions.eq("id", idProduto.longValue()));
		List<Vinil> vinilList = (List<Vinil>) hibernateTemplate.findByCriteria(produtoCriteria);

		if (!userList.isEmpty() && !vinilList.isEmpty()) {
			Usuario usuario = userList.get(0);
			Vinil vinil = vinilList.get(0);
			List<VinilVO> list = usuario.getCarrinho().getProdutos();
			
			for (VinilVO vinilVO : usuario.getCarrinho().getProdutos()) {
				if (vinilVO.getId() == idProduto.longValue()) {
					list.remove(vinilVO);
					break;
				}
			}
			usuario.getCarrinho().setProdutos((ArrayList<VinilVO>) list);
			vinil.setQuantidade(vinil.getQuantidade() + qtd);
			hibernateTemplate.merge(usuario);
			hibernateTemplate.merge(vinil);
			
			return usuario.getId();
		}

		return 0L;
	}

}
