package br.com.senac.controller.dto;

public class ProdutoRequest {
	
	private Long id;

	public Long getId() {
		return this.id;
	}

}
